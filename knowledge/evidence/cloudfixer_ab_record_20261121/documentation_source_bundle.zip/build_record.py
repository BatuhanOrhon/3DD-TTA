"""Compile a documentation-only A/B inventory from accepted immutable artifacts."""
from collections import defaultdict
import csv,datetime,hashlib,json,math,subprocess,zipfile
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'knowledge/evidence/cloudfixer_ab_record_20261121';OUT.mkdir(exist_ok=True)
A=ROOT/'result/modelnet40_c/cloudfixer_point2vec/20261120-184955_full_recount'
B=ROOT/'result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation_recount'
def rows(path):
 with path.open() as stream:return list(csv.DictReader(stream))
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def table(headers,entries):
 return '| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(map(str,row))+' |\n' for row in entries)
asum=rows(A/'summary.csv');aper=rows(A/'per_corruption.csv');apair=rows(A/'paired_policy_differences.csv')
bsum=rows(B/'summary.csv');bper=rows(B/'per_corruption.csv');bpair=rows(B/'paired.csv');diag=json.loads((B/'diagnostics.json').read_text());contrib=json.loads((B/'canonical_contributions.json').read_text())
assert len(asum)==4 and len(aper)==60 and len(apair)==2
assert len(bsum)==279 and len(bper)==4185 and len(bpair)==479
assert {r['seed'] for r in bsum}=={'0','1','2'}
assert {r['method']:int(r['total_correct']) for r in asum}==dict(source=22947,proximal_pm=27748,proximal_terminal=27111,cloudfixer=28596)
tags=['N8_tau0.1','N12_tau0.1','N12_tau0.06666666666666667'];labels=dict(zip(tags,['N8 / τ=.1','N12 / τ=.1','N12 / τ=.8÷12']))
methods=sorted({r['method'] for r in bsum});assert len(methods)==31
pooled=defaultdict(lambda:dict(correct=0,n=0))
for r in bsum:
 assert int(r['total_examples'])==3840 and int(r['n_corruptions'])==15
 p=pooled[(r['schedule'],r['method'])];p['correct']+=int(r['total_correct']);p['n']+=int(r['total_examples'])
assert len(pooled)==93 and all(p['n']==11520 for p in pooled.values())
def pair(tag,method,reference='terminal',seed='pooled'):
 result=[r for r in bpair if r['schedule']==tag and r['method']==method and r['reference']==reference and r['seeds']==seed]
 assert len(result)==1,(tag,method,reference,seed)
 r=result[0];assert int(r['correct'])-int(r['reference_correct'])==int(r['repair'])-int(r['harm'])
 assert math.isclose(float(r['delta_pp']),100*(int(r['correct'])-int(r['reference_correct']))/int(r['n']),abs_tol=1e-12)
 return r
def interval(r,reverse=False):
 lo,hi=float(r['ci95_low_pp']),float(r['ci95_high_pp'])
 if reverse:lo,hi=-hi,-lo
 return f'[{lo:+.6f}, {hi:+.6f}]'
for t in tags:
 for w in ['canonical','all','late']:
  assert pooled[(t,w+'_equal_pm')]==pooled[(t,w+'_exp_beta_0')]
audit=json.loads((ROOT/'knowledge/evidence/cloudfixer_two_colab_20261118/confirmation_id_audit.json').read_text());assert audit['union_n']==136 and audit['confirmation_n']==256 and audit['confirmation_intersection']==[]
pilot=json.loads((ROOT/'knowledge/evidence/cloudfixer_two_colab_20261118/b_pilot_independent_validation.json').read_text());assert pilot['n_modes']==3 and pilot['n_batches']==4 and all(v['correct']==112 for v in pilot['totals'].values())
assert all(r['old_canonical_max_abs']==r['old_dense_max_abs']==0 for r in pilot['batches'])
archives=[('A ham','result/modelnet40_c/cloudfixer_point2vec/20261120-184955_full.zip',136139832,'b2f0685cb1f0c3e0a053dff6e19f71503e9b793ba2ed340ff1eb0c6f6081e42d'),('A analiz','result/modelnet40_c/cloudfixer_point2vec/20261120-184955_full_recount.zip',192235,'8c6f9da76d509213d31de0da88f555ff28acdf98c95588350e123750e80960aa'),('B ham','result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation.zip',395520996,'80ad0b9192690cc4959fafe31fcb53ba6a127a1831da4e44787cf9ed2a57ffb0'),('B analiz','result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation_recount.zip',320749,'0de7f49d376afece37e5d132fa243e2f5d9746494d13d2efe6b5731d8169ec9e')]
for _,name,size,digest in archives:assert (ROOT/name).stat().st_size==size and sha(ROOT/name)==digest
for rev in ['9afa8436b1770e38e148f9093d3edd85a4d9770a','eec1e8b2fe272e9d1f42b6a628cacd5341f1c8c8']:
 assert subprocess.check_output(['git','show',rev+':cloudfixer_diffusion.py'])==(ROOT/'cloudfixer_diffusion.py').read_bytes()
# All report numbers are copies/aggregations of accepted tables; no inference or fitting.
a_names={'source':'Source kontrolü','proximal_pm':'N8/K80/τ=.1 geç PM','proximal_terminal':'N32/K160/τ=.03 gerçek terminal','cloudfixer':'Orijinal CF — plain'}
a_table=table(['Kol','Doğru / 37,020','Doğruluk (%)','Kayıtlı süre (s)','Tepe ayrılmış bellek (MiB)'],[(a_names[r['method']],r['total_correct'],f"{100*float(r['micro_accuracy']):.6f}",f"{float(r['total_runtime_seconds']):.3f}",f"{float(r['peak_gpu_memory_mb']):.3f}") for r in asum])
a_ci=table(['CF referansına karşı','Δ puan','Nominal %95 aralık','Düzeltti / bozdu'],[(a_names[r['method']],f"{float(r['delta_pp']):+.6f}",interval(r),r['repair']+' / '+r['harm']) for r in apair])
ad={}
for r in aper:ad.setdefault(r['corruption'],{})[r['method']]=r
a_corr=table(['Corruption','Source %','N8 PM %','N32 terminal %','CF plain %','PM−CF puan'],[(c,*[f"{100*float(v[m]['accuracy']):.6f}" for m in ['source','proximal_pm','proximal_terminal','cloudfixer']],f"{100*(float(v['proximal_pm']['accuracy'])-float(v['cloudfixer']['accuracy'])):+.6f}") for c,v in ad.items()])
b_primary=[]
for t in tags:
 for method,title in [('late_equal_pm','Geç'),('canonical_equal_pm','Kanonik'),('all_equal_pm','Tüm adımlar')]:
  r=pair(t,method);terminal=pooled[(t,'terminal')];candidate=pooled[(t,method)]
  b_primary.append([labels[t],title,f"{terminal['correct']} ({100*terminal['correct']/11520:.6f})",f"{candidate['correct']} ({100*candidate['correct']/11520:.6f})",r['repair']+' / '+r['harm'],f"{float(r['delta_pp']):+.6f}",interval(r)])
b_table=table(['Ayar','Pencere','Terminal doğru (%)','PM doğru (%)','Düzeltti / bozdu','Δ puan','Nominal %95 aralık'],b_primary)
seed_table=table(['Ayar','Seed','Terminal / 3,840','Geç PM / 3,840','Δ puan','Nominal %95 aralık'],[[labels[t],seed,(r:=pair(t,'late_equal_pm',seed=str(seed)))['reference_correct'],r['correct'],f"{float(r['delta_pp']):+.6f}",interval(r)] for t in tags for seed in range(3)])
# Aggregate each corruption across the same three seeds, never across timesteps.
bc=defaultdict(int)
for r in bper:bc[(r['schedule'],r['method'],r['corruption'])]+=int(r['n_correct'])
b_corr=table(['Corruption','N8 terminal %','N8 geç PM %','N12/.1 terminal %','N12/.1 geç PM %','N12 eşlenmiş terminal %','N12 eşlenmiş geç PM %'],[[c,*[f'{100*bc[(t,m,c)]/768:.6f}' for t in tags for m in ['terminal','late_equal_pm']]] for c in sorted(ad)])
weighted=table(['Ayar','Pencere','Lineer Δ','β=0','β=.5','β=1','β=2','β=4','β=8'],[[labels[t],w,*[f"{100*(pooled[(t,m)]['correct']-pooled[(t,w+'_equal_pm')]['correct'])/11520:+.6f}" for m in [w+'_linear_entropy',*[w+'_exp_beta_'+x for x in ['0','0.5','1','2','4','8']]]]] for t in tags for w in ['canonical','all','late']])
entropy_table=table(['Ayar','Pooled AUC','Aynı yörüngede çift-ağırlıklı AUC','Yörünge-ağırlıklı AUC','Yanlış / tüm yüksek güvenli aday'],[[labels[t],f"{(e:=diag['configurations'][t]['entropy']['all'])['pooled_correct_vs_wrong_auc']:.6f}",f"{e['within_example_pair_auc']:.6f}",f"{e['within_example_mean_auc']:.6f}",f"{e['wrong_confident']} / {e['confident']}"] for t in tags])
margin_table=table(['Ayar','Grup','n','Ortalama p(doğru)−p(sabit rakip), erken → t0','Doğru sınıf top-1 sayıları'],[[labels[t],kind,(g:=next(r for r in contrib['rows'] if r['seed']=='pooled' and r['config']==diag['configurations'][t]['config'])[kind])['count'],' / '.join(f"{q['mean_true_minus_rival']:+.3f}" for q in g['probes']),' / '.join(str(q['top1_true']) for q in g['probes'])] for t in tags for kind in ['harm','repair']])
geo_table=table(['Ayar','Nominal Nτ','Düzeltme RMS toplamı','Terminal−girdi RMS','İlk geç → terminal logit marjı','Ek t0 hareket RMS'],[[labels[t],f"{(cfg:=diag['configurations'][t])['config']['steps']*cfg['config']['tau']:.3f}",f"{cfg['positions'][-1]['mean_cumulative_correction_rms']:.6f}",f"{cfg['positions'][-1]['pre_to_input_rms']:.6f}",f"{next(p for p in cfg['positions'] if p['native']==(20 if t==tags[0] else 27))['mean_pre_logit_margin']:.3f} → {cfg['positions'][-1]['mean_pre_logit_margin']:.3f}",f"{cfg['endpoint']['pre_extra_t0_to_terminal_mean_rms']:.6f}"] for t in tags])
strength_rows=[]
for t,reference in [(tags[1],tags[0]+'/terminal'),(tags[2],tags[1]+'/terminal'),(tags[2],tags[0]+'/terminal')]:
 r=pair(t,'terminal',reference);strength_rows.append([labels[t]+' − '+labels[reference.split('/')[0]],r['repair']+' / '+r['harm'],f"{float(r['delta_pp']):+.6f}",interval(r)])
strength=table(['Terminal karşılaştırması','Düzeltti / bozdu','Δ puan','Nominal %95 aralık'],strength_rows)
obs_rows=[]
for t in tags:
 for method,reference,title,reverse in [('late_post_equal_pm','late_equal_pm','Post geç PM − pre geç PM',False),('last_post_clean','terminal','Son post-clean − gerçek terminal',False),('pre_extra_t0_state','terminal','Gerçek terminal − ek t0 öncesi state',True)]:
  r=pair(t,method,reference);repair,harm=r['repair'],r['harm'];delta=float(r['delta_pp'])
  if reverse:repair,harm=harm,repair;delta=-delta
  obs_rows.append([labels[t],title,repair+' / '+harm,f'{delta:+.6f}',interval(r,reverse)])
observation=table(['Ayar','Karşılaştırma','Düzeltti / bozdu','Δ puan','Nominal %95 aralık'],obs_rows)
readouts={t:{m:dict(**pooled[(t,m)],accuracy=pooled[(t,m)]['correct']/11520) for m in methods} for t in tags}
record=dict(kind='documentation_only_reconciliation_no_new_inference',local_date='2026-11-21',compiled_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),A=dict(summary=asum,per_corruption=aper,paired=apair),B=dict(n_original_objects=256,n_units=1080,n_traces=34560,readout_names=methods,pooled_readouts=readouts,primary_paired=[pair(t,m) for t in tags for m in ['late_equal_pm','canonical_equal_pm','all_equal_pm']],late_per_seed=[pair(t,'late_equal_pm',seed=str(s)) for t in tags for s in range(3)],paired_rows=479,summary_rows=279,per_corruption_rows=4185),raw_and_derived_archives=[dict(label=label,path=name,bytes=size,sha256=digest) for label,name,size,digest in archives])
(OUT/'verified_report_tables.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
text=f'''# CloudFixer A/B: ayrıntılı test envanteri ve sonuçlar

**Derleme: 21 Kasım 2026. GPU deneyleri: 18–20 Kasım 2026.**

[Run/Code] Bu belge tamamlanmış ve kabul edilmiş arşivlerin ortak Türkçe kaydıdır. Yeni model inference'ı, GPU koşusu, hiperparametre araması veya test etiketiyle yeniden seçim yapılmadı. Sayılar mevcut CSV/JSON'lardan toplandı; dört A/B ham ve analiz ZIP'inin boyut/SHA kimliği yeniden kontrol edildi. Tam sayısal derleme: [verified_report_tables.json](evidence/cloudfixer_ab_record_20261121/verified_report_tables.json).

**Ana sonuç:** A'nın tam Point2Vec karşılaştırmasında orijinal plain CloudFixer önde kaldı. B'nin Point-MAE doğrulamasında ise kilitli geç PM pencereleri, aynı proximal yörüngenin kendi terminalini üç ayarda da geçti. Bunlar farklı referanslar ve farklı deneylerdir; birlikte çelişki oluşturmazlar.

## 1. Ortak yöntem ve terimler

[Code] Her iki çalışmada donmuş **resmî CloudFixer XYZ diffusion** kullanıldı; bu bilimsel deneylerde **LION kullanılmadı**. Classifier ağırlıkları güncellenmedi. Bizim kollarımız clean XYZ tahminini gradient-free proximal SCD ile düzeltiyor. Resmî CF kolu, yazarın rotation/delta optimizasyonunu kullanıyor.

| Terim | Bu deneydeki anlamı |
|---|---|
| N | Ters diffusion güncelleme sayısı; classifier çağrı sayısı değildir. |
| K | 500 seviyeli resmî noise takvimindeki başlangıç native indeksi. |
| τ | Proximal düzeltme gücü; PM softmax sıcaklığı değildir. |
| retained=.95 | Proximal SCD'nin iki yönlü seçici eşleşmelerde tuttuğu oran. |
| Pre-clean probe | Denoiser'ın bir adımda verdiği temiz XYZ tahmini; o adımın proximal düzeltmesinden önce okunur. |
| Post-clean probe | Aynı temiz tahminin proximal düzeltmeden sonraki hali. |
| Pre-extra-t0 state | Son nonzero adımın transport işleminden sonraki, ek t0 çağrısından önceki state. Kalıntı gürültü içerir. |
| Gerçek terminal | Ek native t=0 denoiser çağrısından çıkan temiz XYZ; t0'da ayrıca proximal düzeltme yapılmaz. |
| PM | Seçilen adayların classifier softmax olasılık vektörlerinin eşit ortalaması; logit ortalaması veya tek-adım accuracy değildir. |

[Code] Her nonzero adımda akış şöyledir: `state → denoiser clean tahmini → pre gözlemi → proximal SCD → post gözlemi → sonraki state'e transport`. N güncelleme bittikten sonra ek `phi(state, t=0)` çağrısı gerçek terminali üretir. Bu tanım hem A'nın `9afa8436…` hem B'nin `eec1e8b2…` kaynaklarındaki `cloudfixer_diffusion.py` ile byte düzeyinde eşleşir.

**N32 gerçek terminalin açık tanımı:** K160 grid'i `160,155,…,5,0` olur. İlk 32 nonzero seviyede güncelleme, ardından ek t0 denoiser çağrısı vardır: **33 denoiser çağrısı**, nihai bulutta **tek classifier okuması**, **PM kapalı**. N8/K80 geç PM ise **9 denoiser çağrısı** ve **[20,10,0] üzerinde 3 classifier okuması** kullanır. Bu iki A kolunda N/K/τ/readout birlikte değişir.

PM için her adayda `p_t=softmax(logits_t)` hesaplanır, seçilen pencerede `ortalama(p_t)` alınır ve en büyük ortalama olasılığın sınıfı seçilir. A ve B'nin kayıtlı PM hesaplarında softmax float64'tür. Tahmin kuralı gerçek etikete bakmaz; etiketler doğruluk ve teşhis hesabında kullanılır.

## 2. Hangi testleri yaptık?

| Grup | Test/kontrol | Kapsam ve kabul edilen çıktı |
|---|---|---|
| A0 | Ortam/native/veri kontrolü | Yeni VM'lerde kanonik 10 hücre, ayrı cell1 restart/reconnect, CUDA/FPS/KNN/Chamfer/EMD/PVCNN, veri ve checkpoint kimlikleri. Yalnız bilinen cell2 fastrlock istisnası ertelendi; gerçek Python doğrulandı. |
| A1 | Point2Vec entegrasyonu | Resmî mimari, strict checkpoint yükleme, preprocessing/class order, bağımlılıklar; 180 state anahtarı ve [1,40] classifier çıktısı doğrulandı. Eski Point-MAE yolu korundu. |
| A2 | Teknik smoke ve recovery goldens | Background/lidar üzerinde 2'şer nesne; doğrudan resmî classifier, sparse/dense readout, model/input/RNG ve tarihsel XYZ replay kontrolleri. Bunlar tam doğruluk testi değildir. |
| A3 | Tam dört-kol karşılaştırma | 2,468 nesne × 15 corruption × s5 × seed2, B1; her kol 37,020 gözlem. Source, N8 geç PM, N32 terminal ve plain CF. |
| A4 | Kesinti sonrası devam | Her 32 nesnede atomik Drive payload/receipt, SHA ve RNG. 4 VM epizodu tek kampanyayı tamamladı; eski 35,000 gözlem yeniden skorlanmadı. |
| A5 | Sonuç kabulü | 1,170 blok, 60 corruption-sonuç satırı (4×15) ve 4 özet satırı; ham logits/labels/probability/entropy/logSNR/RNG/timing kontrolleri, bağımsız yeniden sayım. |
| B0 | Doğrulama nesneleri | 6 tarihsel arşivdeki 136 farklı ID ile doğrulama kümesinin 256 ID'si arasında sıfır kesişim. |
| B1 | Gözlemci teknik pilotu | Uniform, eski 128 nesne, seed0/B32; 4 batch × dense/sparse/terminal-only = 12 payload. Eski canonical/dense logits farkı 0. |
| B2 | Kilitli hipotez doğrulaması | 256 nesne × 15 corruption × 3 seed × 3 schedule; 1,080 batch birimi, 34,560 yörünge. |
| B3 | Erken/geç oylar | Kanonik, tüm-adım ve kilitli geç eşit PM; repair/harm ve sabit rakibe karşı probe marjları. |
| B4 | Entropy | Pooled ve aynı-yörünge AUC; 3 pencerede lineer ve 6 β'lı üstel ağırlık ailesi. |
| B5 | Birikimli düzeltme | N8/.1, N12/.1, N12/(.8÷12); Nτ, RMS, marj ve terminal geçişleri. |
| B6 | Gözlem yeri ve ek t0 | Pre/post PM, son post-clean, pre-extra state ve gerçek terminal eşleştirmeleri. |
| B7 | Offline readout ve arşiv kabulü | 31 kayıtlı readout adı; 279 özet, 4,185 corruption satırı, 479 paired kontrast; ham/analiz arşivi ve ikinci Drive mount geri okuması. |

## 3. A — tam ModelNet40-C / Point2Vec karşılaştırması

### 3.1 Protokol

[Run] Tam 2,468 test nesnesi, aynı 15 corruption, severity 5, yazar seed'i **2**, batch **1**. Aynı donmuş Point2Vec ve aynı resmî diffusion checkpoint'i kullanıldı. İki proximal kolda retained=.95 sabit; N8/K80/τ=.1 geç PM `[20,10,0]`, N32/K160/τ=.03 gerçek terminal. Kollar tam test etiketleri görülerek yeniden ayarlanmadı.

Source, yazar akışındaki adaptation öncesi classifier kontrolüdür. Plain CF ilk classifier çıktısıdır. Resmî ikinci vote1 forward'ı RNG akışını korumak için çalışır ve ayrıca teşhis olarak kaydedilir. Bunları bağımsız paper-reproduction source ölçümü veya aynı readout olarak birleştirmiyoruz.

### 3.2 Ana doğruluk, süre ve bellek

{a_table}

[Run] Diagnostic vote1 **28,545/37,020 = 77.106969%**; ana plain CF sayısı **28,596**'dır. N8 PM'nin kayıtlı yöntem süresi CF'ninkinin yaklaşık **1/3.20**'sidir. Zamanlar CUDA synchronize ile ölçülür; diagnostic vote forward'ı, gate, I/O ve setup hariçtir. Bunlar bütün dağıtımın uçtan uca hızlanma veya fatura ölçümü değildir. `peak_gpu_memory_mb` alanının gerçek birimi MiB'dir.

### 3.3 Eşleştirilmiş doğruluk farkları

{a_ci}

[Run] 10,000 PCG64 bootstrap draw, seed20261118; 2,468 orijinal nesne tüm 15 corruption'ıyla birlikte yeniden örneklenir. Aralıklar A'nın sabit seed'i ve native gerçekleşmesine koşulludur. Seed/native koşular-arası varyansı vermez.

[Inference] **İki sabit proximal politika bu koşulda plain CF'ı geçmedi.** N8 PM, N32 terminalden 637 olay / **+1.7206915 puan** öndedir; farklı N/K/τ nedeniyle bu PM'nin tek başına nedensel etkisi sayılamaz. N8 PM'nin kendi N8 terminaline karşı referansı A'nın bu ana tablosunda ayrı bir kol değildir; aynı-yörünge readout hipotezi B'de Point-MAE ile test edilir.

### 3.4 Corruption bazında tüm sonuçlar

{a_corr}

[Run] PM CF'ı 6/15 corruption'da, N32 terminal 3/15 corruption'da geçer. PM'nin toplam 848 doğru-tahmin açığının 529'u rotation, 266'sı background kaynaklıdır: **795/848 = 93.75%**. Bu tablo bunları ana ortalamadan çıkarma veya test etiketleriyle yeni ayar seçme gerekçesi değildir. [Inference] Açığın bu iki bozulmada yoğunlaşması, geometrik neden veya rotation optimizasyonunun nedensel katkısını tek başına kanıtlamaz.

### 3.5 Smoke, yeniden başlatma ve bütünlük

[Run] Her replacement VM'de bilimsel kaynak/asset/environment imzaları ve fresh-empty-store goldens kontrol edildi. Source ve iki proximal kolun deterministik çıktıları tam eşleşti; geçmiş adapted XYZ'nin classifier replay'i tam eşleşti. Native KNN backward sayısal olarak deterministik değildir: r12 smoke'da 4 tahminin 1'i değişmişti; r13 smoke'da 0/4 argmax değişimi olsa da plain logits farkları background'da .433021486, lidar'da .419406652 idi. Bu, tam koşular-arası performans varyansını ölçmez.

| Epizot | Yeni blok | Yeni gözlem |
|---|---:|---:|
| r3 | 847 | 26,824 |
| r9 | 182 | 5,740 |
| r12 | 77 | 2,436 |
| r13 | 64 | 2,020 |
| Toplam | 1,170 | 37,020 |

[Run] Bunlar dört bağımsız seed deneyi değil, tek sabit kampanyanın devam epizotlarıdır. Son arşivde önceki **2,212 ham dosya / 35,000 gözlem** byte düzeyinde değişmeden korunur. Primary analyzer ve ikinci bağımsız ham-logit sayımı bütün doğru sayıları doğruladı.

## 4. B — aynı-yörünge PM/terminal hipotezleri

### 4.1 Doğrulama kapsamı ve bağımsızlık

[Run] Donmuş **Point-MAE**, aynı resmî XYZ diffusion; **256 ayrılmış orijinal nesne**, 15 corruption, s5, seed **0/1/2**, B32, K80, retained=.95. Üç schedule: N8/.1, N12/.1 ve N12/τ=.8÷12=.0666666667. Her schedule/seed 3,840; üç seed havuzunda her schedule **11,520** gözlem vardır. Toplam **34,560 schedule-özgü yörünge**, bağımsız 34,560 nesne değildir.

[Run] Geç pencereler **N8 `[20,10,0]`**, **N12 `[27,0]`** olarak önceki geliştirme logits'lerinden seçilip doğrulamadan önce kilitlendi. Altı tarihsel arşivdeki 136 ID ile yeni 256 ID'nin kesişimi sıfırdır. Bağımsızlık bu hipotezler için nesne ayrımına aittir; benchmark daha önce incelenmiş olduğundan bütün benchmark'ın hiç görülmediği iddia edilmez.

[Code/Run] 31 kayıtlı readout: 1 terminal + 3 eşit PM + 21 entropy-ağırlıklı PM + 3 post-PM + 3 tek-gözlem teşhisi. β=0 kolları eşit PM ile tam aynı sonucu verir; dolayısıyla 31 bağımsız algoritma değildir. İsimlerin tamamı ve 93 schedule/readout havuz sonucu JSON kanıtında yer alır. Aynı kayıtlı yörüngeler offline yeniden okunur; 31 yeni GPU koşusu yapılmaz.

### 4.2 Teknik pilot sonucu

[Run] Uniform/seed0 üzerinde aynı 128 eski geliştirme nesnesi dense, sparse ve terminal-only modlarında işlendi. Her modda gerçek terminal **112/128**. Eski canonical-four ve dense-nine logits ile maksimum mutlak fark **0**; input/model/RNG/transport/endpoint kontrolleri geçti. Süreler: dense **18.542214 s**, sparse **10.970161 s**, terminal-only **9.977568 s**. Bunlar küçük teknik pilotun gözlem maliyetidir; tam doğruluk kıyası değildir.

### 4.3 Erken, kanonik, tüm-adım ve geç PM

[Run] Kanonik pencere N8'de `[70,50,30,0]`, N12'de `[67,47,27,0]`; tüm-adım penceresi 9 veya 13 pre-clean/terminal adayını kullanır. PM olasılık ortalamasıdır. Tablodaki her satır aynı yörüngenin kendi terminaliyle eşleştirilmiştir. Her hücrenin paydası 11,520'dir.

{b_table}

[Run] Geç pencere bütün üç ayarda terminalin üstündedir; üç pooled aralık da sıfırın üstünde. Kanonik ve tüm-adım PM'nin işareti schedule'a göre değişir. Geç−kanonik farkı N8'de **+1.440972 puan**, N12/.1'de **+0.399306**, eşlenmiş N12'de **+1.180556**; N12/.1 geç−kanonik aralığı sıfırı içerir. N8 geç pencere aynı zamanda t20/t10'u eklediği için tüm fark yalnız erken adayları çıkarmaya bağlanamaz.

### 4.4 Seed bazında geç PM doğrulaması

{seed_table}

[Run] Dokuz seed nokta farkının hepsi pozitiftir; yedisinin nominal aralığı sıfırı dışlar. N8 seed0 ve eşlenmiş N12 seed0 aralıkları sıfırı içerir. B aralıkları 10,000 paired draw ile 256 orijinal nesneyi bütün corruption ve seed'leriyle birlikte örnekler; çoklu karşılaştırma düzeltmesi yapılmamıştır.

### 4.5 Corruption bazında terminal / geç PM

[Run] Her hücre 256 nesne × 3 seed = 768 gözlemden hesaplandı.

{b_corr}

[Run] N8 geç−terminal 15/15 corruption'da pozitiftir. N12/.1'de 13/15 pozitif, cutout ve density_inc'de üçer olay negatiftir. Eşlenmiş N12'de 11/15 pozitif, uniform eşit; cutout −5, distortion −1, upsampling −1 olaydır. Hiçbir corruption'a özel policy seçilmedi.

### 4.6 Erken yanlış oylar geç doğru kararı bastırıyor mu?

[Run] Kanonik PM'deki harm grubunda yanlış rakip PM'nin seçtiği sınıftır; repair grubunda terminalin seçtiği yanlış sınıftır. Her probe için aynı rakibe karşı `p(doğru)−p(rakip)` ölçülür. Aşağıdaki marjlar grup ortalamalarıdır; gruplar sonuca göre tanımlandığından bu bir fiziksel nedensellik deneyi değildir.

{margin_table}

[Run] N8'de terminal doğruyken kanonik PM'nin bozduğu **303** olayın ilk probe'unda **252** kez nihai yanlış rakip, yalnız **17** kez gerçek sınıf top-1'dir. Erken iki negatif marj, terminalin pozitif marjını olasılık ortalamasında bastırabilir. Buna karşılık erken doğru oylar da terminal hatalarını onarır: N8'de 241 repair, N12/.1'de 389 repair vardır. [Inference] Erken adaylar koşulsuz zararlı değildir; net denge schedule'a bağlıdır.

### 4.7 Entropy aynı nesnenin doğru adımını seçebiliyor mu?

{entropy_table}

[Run] Skor negatif entropy'dir; düşük entropy'nin doğru adayı öne alması sınanır. Pooled AUC farklı nesne/adımları karıştırır; aynı-yörünge AUC aynı nesne/corruption/seed/schedule içindeki doğru-yanlış çiftlerini karşılaştırır, tie yarım sayılır. Yaklaşık .867–.868 pooled ilişki, aynı yörüngede .635–.647'ye düşer. Yörünge başına eşit ağırlıkta yaklaşık .654–.658'dir. `max p≥.9` adaylar arasında binlerce yanlış tahmin bulunur; yüksek güven doğru etiket garantisi değildir.

**Ağırlık testleri:** `w_linear∝1−H/log(40)` (eşit fallback) ve `w_exp∝exp(−βH)`; β = 0,.5,1,2,4,8. Aşağıdaki değerler aynı penceredeki eşit PM'ye göre **yüzde puan farkıdır**.

{weighted}

[Run] Lineer ve β1, geç pencerede üç ayarda da tutarlı kazanç sağlamadı; bu nominal geç-pencere aralıkları sıfırı içerdi. β8, tüm-adım PM'yi her ayarda düşürdü. Aile bütünü raporlanır; doğrulama etiketlerine göre kazanan β seçilmez. [Inference] Entropy kısmi sıralama bilgisi taşıyor, fakat basit ağırlıklandırma burada güvenilir ek fayda göstermedi; her olası entropy seçicisinin imkânsız olduğu sonucu çıkmaz.

### 4.8 N artınca birikimli düzeltme terminali bozuyor mu?

{geo_table}

{strength}

[Run] Sabit τ=.1 ile N8→N12, nominal Nτ'yı .8→1.2 ve düzeltme RMS toplamını .099893→.133604 yükseltti; terminal **−1.588542 puan** düştü. N12'de τ=.8÷12 yapılınca **174** net doğru tahmin geri geldi: **+1.510417 puan**. Eşlenmiş N12 terminali N8'den yalnız **−.078125 puan** farklı; aralık sıfırı içerir.

[Inference] Bu sınırlı kontrol terminal açığının birikimli düzeltme gücüne duyarlı olduğunu destekler. Aynı Nτ, aynı zaman ayrıklaştırması veya aynı yörünge anlamına gelmez. İlk geç doğru/terminal yanlış grubu ile tersi grubun kalan düzeltme RMS'leri birbirine çok yakındır: N8 .020849/.020877; N12/.1 .035668/.035222; eşlenmiş N12 .029027/.028957. Dolayısıyla tek nesnede bozulmayı yalnız kalan düzeltme büyüklüğüyle açıklayan genel overshoot kanıtı yoktur.

### 4.9 Pre/post gözlem ve ek t0 neyi değiştirdi?

{observation}

[Run] Post PM, seçilen nonzero adımların düzeltme sonrası clean bulutlarını ve aynı gerçek terminali kullanır. Son post-clean bulut transport öncesidir; pre-extra state transport sonrasıdır; gerçek terminal ek t0 denoiser çağrısının çıktısıdır. Bu üç farklı nesne birbirinin yerine adlandırılmaz.

[Inference] Ek t0 çağrısı bu üç ayarda net pozitif fark verdi; eşlenmiş N12 aralığı sıfırı içerdi. Post gözleme geçmek N8 geç PM'yi nominal olarak azalttı; N12'lerde işaret/kararlılık ortak değildir. Evrensel “post daha iyi” veya “son t0 çağrısı bozuyor” sonucu desteklenmedi. Bu deneyler LION decoder'ına ait bir üstünlüğü test etmez.

### 4.10 Süre, bellek ve tekrar sayımı sınırı

[Run] B doğrulama fazı **8,414.28089 s (2 saat 20 dakika 14 s)** sürdü. Schedule başına üç seed'in tanısal süre toplamları N8 **1,872.13 s**, N12/.1 **2,619.04 s**, eşlenmiş N12 **2,618.91 s**; tepe ayrılmış bellek sırasıyla **9,287.39 / 9,293.40 / 9,293.40 MiB**. Bu pipeline pre/post classifier gözlemlerini ve bütün offline readout'lara ortak teşhis maliyetini içerir. 31 readout'un CSV sürelerini toplayarak 31 ayrı GPU koşusu maliyeti üretmek hatalıdır. A/B süre ve belleği farklı backbone/batch/observer kapsamları nedeniyle doğrudan verimlilik kıyası değildir.

## 5. A ile B birlikte ne söylüyor?

| Soru | Kanıtın desteklediği sonuç | Desteklenmeyen daha güçlü iddia |
|---|---|---|
| Seçilen paket Point2Vec'te CF'ı geçti mi? | A'da iki sabit proximal politika CF'ın altında kaldı. | Proximal/PM her backbone ve ayarda kötüdür. |
| Geç PM kendi terminalini geçebilir mi? | B'de kilitli geç pencereler üç pooled ayarda pozitiftir; 9 seed nokta farkı da pozitiftir. | Her pencere/her seed aralığı veya her corruption kesin pozitiftir. |
| Erken oylar bastırıyor mu? | Bazı canonical harm gruplarında erken yanlış sınıf lehine güçlü oylar var. | Erken adımlar her zaman zararlıdır veya geometry bozulmasının nedeni kanıtlandı. |
| Entropy güvenilir seçim mi? | Pooled ilişki güçlü, aynı-yörünge ilişki daha zayıf; sabit ağırlıklarda tutarlı ek kazanç yok. | Entropy kusursuz seçici ya da bütünüyle bilgisizdir. |
| Nτ mekanizması? | N12'de gücü azaltmak terminal açığının çoğunu kapattı. | Eşit Nτ eşit dinamik veya nesne bazında kanıtlanmış overshoot'tur. |
| Ek t0 / pre-post? | Okuma yeri önemlidir; ekstra t0 yardımcı olabilir; ortak bir pre/post üstünlüğü yok. | Son probe, son post-clean, noisy state ve gerçek terminal aynı şeydir. |

## 6. Arşivler, kaynaklar ve operasyonel kapanış

[Run] A ham/analiz ve B ham/analiz arşivleri yeniden yazılmadı. Kaynak/etiket/model/RNG/SHA/CRC kabul kayıtları ve özgün analizler korunur. A'da PM penceresi önceki geliştirme keşfinden kilitlendi; full test tüm geliştirme nesnelerini de içerir. B nesne ayrımı bu hipotezlere özgüdür. A tek seed; B üç sabit seed'e koşulludur; tekrar seed ve corruption'lar bağımsız nesne sayısını artırmaz.

'''
for label,name,size,digest in archives:text+=f'- **{label}:** [{Path(name).name}](../{name}); {size:,} byte; SHA256 `{digest}`.\n'
text+='''
[Run] A'nın son oturumu `tta-cloudfixer-point2vec-recovery-a100-20261120-r13`, endpoint `gpu-a100-s-usw4b0-3turcmp9s9iyb`; scientific/preservation kabulünden sonra resmî Drive flush/unmount ve açık kullanıcı talimatıyla stop yapıldı. **20 Kasım 20:35:58 UTC** sunucu envanteri oturumun yokluğunu, 0 aktif atama ve 0 CU/saat gösterir. 21 Kasım kayıt kontrolünde de sunucu envanteri boş bulundu. B oturumu `tta-cloudfixer-pm-hypotheses-a100-20261118-r13` daha önce dışarıdan kaybolmuştu; agent tarafından kapatılmış gibi sunulmaz. Bilimsel çıktıları bu kayıptan önce ikinci mount ile korunmuştu.

Kaynaklar: A `9afa8436b1770e38e148f9093d3edd85a4d9770a`; B `eec1e8b2fe272e9d1f42b6a628cacd5341f1c8c8`; resmî CloudFixer `f043e24414fcf4165fdc892abff21215c9989141`. Point2Vec, Point-MAE, diffusion, label ve environment SHA ayrıntıları ayrı A/B raporlarında ve arşiv config/environment dosyalarında bulunur. Operasyonel duraklamalar, başarısız tahsisler, bütçe değişiklikleri ve kurtarma kaynakları [yürütme günlüğünde](cloudfixer_two_colab_execution_20261118.md) saklanır; başarısız geçmiş silinmez.

## 7. Tam kayıtların okuma sırası

1. Bu ortak envanter: hangi testin hangi soruyu cevapladığı ve karşılaştırma sınırları.
2. [A tam Point2Vec raporu](cloudfixer_point2vec_full_results_20261120.md): tam benchmark, bütün corruption'lar, recovery ve kapanış.
3. [B doğrulama raporu](cloudfixer_pm_hypotheses_confirmation_20261118.md): ilk ayrıntılı hipotez kaydı, tablolar ve özgün evidence bağlantıları.
4. [A sayım/CI dosyaları](../result/modelnet40_c/cloudfixer_point2vec/20261120-184955_full_recount/summary.csv), [B 279 özet satırı](../result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation_recount/summary.csv), [B 479 kontrast](../result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation_recount/paired.csv), [B diagnostics](../result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation_recount/diagnostics.json), [B canonical contribution](../result/modelnet40_c/cloudfixer_hypotheses/20261118-093757_confirmation_recount/canonical_contributions.json).
5. [Bu derlemenin kompakt sayısal kanıtı](evidence/cloudfixer_ab_record_20261121/verified_report_tables.json) ve kaynak kimliği makbuzu.

[Open] A'da seed/native varyansı, Point2Vec'te aynı N/K/τ ile PM–kendi terminali ayrımı ve rotation/background açığının fiziksel nedeni çözülmüş değildir. Bunlar gelecekte bağımsız geliştirme protokolü gerektiren bilimsel sorulardır; bu tamamlanmış görevde bekleyen test veya yeni GPU izni olarak kaydedilmez.
'''
report=ROOT/'knowledge/cloudfixer_ab_detailed_tests_results_20261121.md';assert not report.exists();report.write_text(text)
inputs=[A/'summary.csv',A/'per_corruption.csv',A/'paired_policy_differences.csv',B/'summary.csv',B/'per_corruption.csv',B/'paired.csv',B/'diagnostics.json',B/'canonical_contributions.json',ROOT/'cloudfixer_diffusion.py',ROOT/'knowledge/evidence/cloudfixer_two_colab_20261118/b_pilot_independent_validation.json',ROOT/'knowledge/evidence/cloudfixer_two_colab_20261118/confirmation_id_audit.json']
receipt=dict(status='documentation_tables_verified_no_new_model_run',compiled_utc=record['compiled_utc'],source_head=record['source_head'],inputs={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in inputs},archives=record['raw_and_derived_archives'],report_sha256=sha(report),tables_sha256=sha(OUT/'verified_report_tables.json'),counts=dict(A_summary=4,A_corruption=60,B_summary=279,B_corruption=4185,B_paired=479,B_readouts=31,B_pooled_readouts=93))
(OUT/'source_receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print('A_B_DETAILED_RECORD_BUILT',len(text.splitlines()),'lines',len(text.encode()),'bytes',sha(report))
